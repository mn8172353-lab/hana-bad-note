# はなのバド上達ノート (PWA)

小3の瑛のバドミントン練習記録アプリ。サーバー不要の静的サイト。

## 構成
- index.html … アプリ本体（HTML/CSS/JSが1ファイル）
- manifest.webmanifest … PWA設定（name, display: standalone, icons）
- sw.js … Service Worker（ネット優先・失敗時キャッシュ）
- icons/ … 192 / 512 / maskable 512 / apple-touch

## 画面
練習 / 目標 / 大会 / ママ（4タブ。下部固定ナビ）

## データ
- localStorage キー `hana_bad_v1`（変更禁止。変更すると既存の記録が見えなくなる）
- 練習記録: practices[{id,date,menus[],other,good,bad,coach,nexts[],review[{text,done}],mama}]（旧形式 next(文字列)は nextsOf() で吸収）
- 目標: goals{"YYYY-MM":[{id,title,weeks[5]}]}（旧形式は normalize() で自動変換）
- 大会: tournaments[{id,name,date,goal,events[{type:シングルス|ダブルス,goal}],focus[],focusOther,matches[{id,opp,g[[瑛,相手]×3],coach,mama}]}]（旧形式 tournament は normalize() で自動変換）
- 旧メニュー名「クリア」は normalize() で「クリアー」に統一
- データはオリジン（URL）ごとに別。ホスティング先URLを変えると記録は引き継がれない。
- バックアップ: 大会画面の「書き出し/読み込み」「テキストでコピー/貼り付け」でJSONを出し入れできる。

## ママ用ページ
- 月ごと（◀▶）/全期間で分析。記録の文章を THEMES（index.html内のキーワード表）で分類して集計。
- 分類を変えたいときは THEMES の w（キーワード）を編集。将来AI分析に差し替える場合は analyze() を置き換える。

## 改修ルール
- パスは相対パスのまま（GitHub Pagesのサブパスでも動かすため）。
- 変更したら sw.js の `CACHE` 番号を上げる。
- 新しいファイルを追加したら sw.js の ASSETS にも追加。
- HTTPSで配信すること（localhost は可）。

## 公開手順
GitHub Pages / Netlify / Cloudflare Pages にこのフォルダをそのまま置く。
Android Chrome で開き、メニュー →「アプリをインストール」または「ホーム画面に追加」。
